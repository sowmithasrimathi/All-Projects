clear all;close all;clc;
thresh = 40; 
prompt = 'enter the starting frame no.';
prompt2 = 'enter the end frame no.';

srt_frame = 756;%input(prompt);
end_frame = 765;%input(prompt2);

bg = imread(strcat('./frames/frame',int2str(srt_frame),'.jpg')); % read in 1st frame as background frame
bg_bw = rgb2gray(bg); % convert background to greyscale
% ----------------------- set frame size variables -----------------------
fr_size = size(bg); 
width = fr_size(2);
height = fr_size(1);
fg = zeros(height, width);
% --------------------- process frames -----------------------------------
for i = srt_frame+1 :end_frame
fr = imread(strcat('./frames/frame',int2str(i),'.jpg')) ; % read in frame
fr_bw = rgb2gray(fr); % convert frame to grayscale 
fr_diff = abs(double(fr_bw) - double(bg_bw)); 
for j=1:width 
for k=1:height
if ((fr_diff(k,j) > thresh))
fg(k,j) = fr_bw(k,j);
else
fg(k,j) = 0;
end
end
end
bg_bw = fr_bw;
figure(1),subplot(3,1,1),imshow(fr)
subplot(3,1,2),imshow(fr_bw)
subplot(3,1,3),imshow(uint8(fg)),title('FG-PLayer');
end